import random

def initial_population(population_size, board_size):
    return [[random.randint(0, board_size - 1) for _ in range(board_size)] for _ in range(population_size)]

def fitness(chromosome):
    n = len(chromosome)
    attacking_pairs = sum(chromosome[i] == chromosome[j] or abs(i - j) == abs(chromosome[i] - chromosome[j]) for i in range(n) for j in range(i + 1, n))
    non_attacking_pairs = n * (n - 1) // 2
    fitness_value = non_attacking_pairs - attacking_pairs
    return fitness_value

def two_max_indices(my_list):
    if len(my_list) < 2:
        raise ValueError("List must have at least two elements")

    max1_index = max(range(len(my_list)), key=my_list.__getitem__)
    max1_value = my_list[max1_index]

    # Set the first maximum value to a very small number to find the second maximum
    my_list[max1_index] = float('-inf')

    max2_index = max(range(len(my_list)), key=my_list.__getitem__)
    max2_value = my_list[max2_index]

    return max1_index, max2_index

def selection(population, fitness_values):
    max_indexes = two_max_indices(fitness_values)
    return population[max_indexes[0]], population[max_indexes[1]]

def crossover(parent1, parent2):
    crossover_point = random.randint(1, len(parent1) - 1)
    child1 = parent1[:crossover_point] + parent2[crossover_point:]
    child2 = parent2[:crossover_point] + parent1[crossover_point:]
    return child1, child2

def mutation(chromosome, mutation_rate):
    mutated_chromosome = chromosome.copy()

    for i in range(len(mutated_chromosome)):
        if random.random() < mutation_rate:
            mutated_chromosome[i] = random.randint(0, len(mutated_chromosome) - 1)

    return mutated_chromosome

def genetic_algorithm(population_size, board_size, mutation_rate, target_fitness):
    population = initial_population(population_size, board_size)

    while True:
        fitness_values = [fitness(chromosome) for chromosome in population]
        # for target value any one chromosome
        # if max(fitness_values) >= target_fitness:

        # for target value 3 or more
        if sum(fitness >= target_fitness for fitness in fitness_values) >= 3:
            break

        new_population = []

        for _ in range(population_size // 2):
            parent1, parent2 = selection(population, fitness_values)

            child1, child2 = crossover(parent1, parent2)

            child1 = mutation(child1, mutation_rate)
            child2 = mutation(child2, mutation_rate)

            new_population.extend([child1, child2])

        population = new_population

    # Return the best solution found
    best_solution = max(population, key=fitness)
    return best_solution, fitness(best_solution), population

# Example usage
population_size = 4
board_size = 8
mutation_rate = 0.1
target_fitness = 27

best_result, best_fitness, population = genetic_algorithm(population_size, board_size, mutation_rate, target_fitness)
print("Solution:", best_result)
print("Fitness:", best_fitness)

print("All solutions:")
for count, p in enumerate(population, start=1):
    print(f"P{count} Chromosome {p}  fitness {fitness(p)}")